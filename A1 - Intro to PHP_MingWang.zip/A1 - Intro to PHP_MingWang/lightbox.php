<?php

/*******w******** 
    
    Name: Ming Wang
    Date: 1/24/2024
    Description:

****************/

/*
$config = [

    'gallery_name' => 'Name of Your Gallery',
 
    'unsplash_categories' => ['array','of','category','keywords'],
 
    'local_images' => ['array','of','local','image','filenames']
 
];
*/

//Update
$config = [

    'gallery_name' => 'Ming Gallery',
 
    'unsplash_categories' => ['Animals', 'Film', 'Travel', 'Nature', ],
 
    'local_images' => [
                        ['Animal' => 'Alligators',
                        'Author' => 'Laura College',
                        'href' => 'https://unsplash.com/@laura_college'],
                        ['Animal' => 'PolarBear',
                        'Author' => 'Hans-Jurgen Mager',
                        'href' => 'https://unsplash.com/@hansjurgen007'],
                        ['Animal' => 'ArcticFox',
                        'Author' => 'Jonatan Pie',
                        'href' => 'https://unsplash.com/@r3dmax'],
                        ['Animal' => 'Panda',
                        'Author' => 'Lukas W.',
                        'href' => 'https://unsplash.com/@theluki']
    ]

];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/luminous-lightbox/2.0.1/luminous-basic.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/luminous-lightbox/2.0.1/Luminous.min.js"></script>
    <title>Lightbox Gallery</title>
</head>
<body>

    <h1><?= $config['gallery_name'] ?></h1>

    <!-- Display Local Images with Thumbnails -->
    <div class="image-gallery">
        <?php foreach($config['local_images'] as $image): ?>
            <a href="images/<?= $image['Animal'] ?>.jpg" class="luminous-link">
                <img src="images/<?= $image['Animal'] ?>_thumbnail.jpg" alt="<?= $image['Animal'] ?>" class="thumbnail">
            </a>
        <?php endforeach; ?>
    </div>

    <script>
       new LuminousGallery(document.querySelectorAll(".image-gallery .luminous-link"));
    </script>

</body>
</html>
