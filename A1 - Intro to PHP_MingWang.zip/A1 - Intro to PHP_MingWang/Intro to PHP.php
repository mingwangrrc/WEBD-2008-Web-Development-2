<?php
$tasty_treats = [
    'zaaah'   => ['name' => 'pizza', 'image' => 'pizza.png'],
    'chips'   => ['name' => 'french fries', 'image' => 'fries.png'],
    'burger'  => ['name' => 'hamburger', 'image' => 'burger.png'],
    'sheights'=> ['name' => 'Silver Height lagers', 'image' => 'beer.png']
];

foreach($tasty_treats as $tasty_treat => $info):
    // Your code for the next questions will go here.
endforeach;
?>

<?php
foreach($tasty_treats as $tasty_treat => $info):
    echo "<p>Let's order some {$info['name']}</p>";
endforeach;
?>

<?php
foreach($tasty_treats as $tasty_treat => $info):
    echo "<p>Let's order some {$tasty_treat}, I mean {$info['name']}</p>";
endforeach;
?>

<?php
foreach($tasty_treats as $tasty_treat => $info):
    echo "<p>Let's order some {$tasty_treat}, I mean {$info['name']} <img src='{$info['image']}' alt='{$info['name']}'></p>";
endforeach;
?>