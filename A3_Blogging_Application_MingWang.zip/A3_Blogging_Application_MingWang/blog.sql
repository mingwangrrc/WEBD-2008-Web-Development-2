-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2024 at 09:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serverside`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `content` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `timestamp`, `content`) VALUES
(54, 'Ming&#039;s Secret Kung Pao Chicken', '2024-03-03 20:02:51', 'Ingredients:\r\nChicken:\r\n\r\n500g boneless chicken breast, diced\r\n2 tsp soy sauce\r\n2 tsp Shaoxing wine(any light favour liqour or cooking wine)\r\n1 tsp cornstarch\r\nSauce:\r\n\r\n3 tbsp soy sauce\r\n2 tbsp Chinkiang vinegar\r\n1 tbsp hoisin sauce(normally oyster sauce)\r\n1 tbsp sugar\r\n1 tsp sesame oil\r\n1/2 cup (120ml) chicken stock or water\r\n2 tsp cornstarch\r\nStir-fry:\r\n\r\n3 tbsp vegetable oil\r\n8-10 dried red chilies, deseeded and halved\r\n1 tsp Sichuan peppercorns\r\n1 large bell pepper, diced\r\n1/2 cup (75g) roasted peanuts or cashews\r\n3 green onions, chopped\r\n2 cloves garlic, minced\r\n1 tsp ginger, minced\r\n\r\n\r\nInstructions:\r\nMarinate Chicken: In a bowl, mix diced chicken with 2 tsp soy sauce, 2 tsp Shaoxing wine, and 1 tsp cornstarch. Set aside for 15-20 minutes.\r\n\r\nPrepare Sauce: In another bowl, combine 3 tbsp soy sauce, 2 tbsp Chinkiang vinegar, 1 tbsp hoisin sauce, 1 tbsp sugar, 1 tsp sesame oil, 1/2 cup chicken stock, and 2 tsp cornstarch. Stir well and set aside.\r\n\r\nStir-fry Chicken: Heat 2 tbsp of vegetable oil in a wok over high heat. Add the marinated chicken and stir-fry until it&#039;s nearly cooked through. Remove chicken from the wok and set aside.\r\n\r\nSaut&eacute; Aromatics: In the same wok, add 1 tbsp oil, dried red chilies, and Sichuan peppercorns. Stir-fry for about 30 seconds until fragrant.\r\n\r\nAdd Vegetables: Add the diced bell pepper and stir-fry for a minute.\r\n\r\nCombine Chicken: Return the chicken to the wok and mix well.\r\n\r\nAdd Sauce: Stir the sauce mixture again then pour it into the wok. Stir constantly until the sauce thickens.\r\n\r\nFinal Touches: Add roasted peanuts or cashews, chopped green onions, minced garlic, and ginger. Stir well to combine everything.\r\n\r\nServe: Serve hot with steamed rice or noodles.\r\n\r\nThis detailed recipe can serve as a template for your blog, highlighting specific measurements and steps to recreate Ming&#039;s unique culinary style. Feel free to adjust the recipe to suit your personal preferences or to highlight your own secret ingredients!'),
(55, 'Ming&#039;s Style Har Gow (Shrimp Dumplings)', '2024-03-03 20:10:18', 'Ingredients:\r\nDough:\r\n\r\n1 cup (120g) wheat starch\r\n1/2 cup (60g) tapioca starch\r\n1 cup (240ml) boiling water\r\n1 tsp vegetable oil\r\nFilling:\r\n\r\n300g raw shrimp, peeled, deveined, and finely chopped\r\n1 tbsp bamboo shoots, finely chopped\r\n1 tsp soy sauce\r\n1 tsp sesame oil\r\n1 tsp Shaoxing wine\r\n1/2 tsp sugar\r\n1/4 tsp salt\r\n1/4 tsp white pepper\r\n1 tsp cornstarch\r\n2 green onions, finely chopped\r\nInstructions:\r\nPrepare Dough: In a large bowl, mix wheat starch and tapioca starch. Pour in boiling water and vegetable oil. Stir quickly with a spatula until a dough starts to form. When cool enough to handle, knead until smooth. Cover and set aside for 30 minutes.\r\n\r\nMake Filling: In another bowl, combine chopped shrimp, bamboo shoots, soy sauce, sesame oil, Shaoxing wine, sugar, salt, white pepper, cornstarch, and green onions. Mix well and set aside.\r\n\r\nShape Dumplings: Divide the dough into small portions, about the size of a golf ball. Roll each portion into a thin circle (about 3 inches in diameter). Place a small amount of filling in the center of each circle. Fold and pinch the edges to form a pleated crescent shape, ensuring the dumpling is sealed.\r\n\r\nSteam Dumplings: Prepare a steamer by lining it with parchment paper or cabbage leaves. Place the dumplings in the steamer, ensuring they don&#039;t touch each other. Steam over high heat for 6-8 minutes, or until the dough is translucent and the shrimp filling is cooked.\r\n\r\nServe: Serve the Har Gow immediately with soy sauce or a dipping sauce of your choice.'),
(56, 'Ming&#039;s Aromatic Peking Duck', '2024-03-03 20:11:57', 'Ingredients:\r\nDuck:\r\n\r\n1 whole duck (about 2-3 kg)\r\n1 tbsp honey\r\n1 tbsp Shaoxing wine\r\n1 tbsp soy sauce\r\n1 tsp five-spice powder\r\n1 tsp salt\r\nTo Serve:\r\n\r\n20 Chinese pancakes\r\n1 cucumber, julienned\r\n1 bunch spring onions, cut into strips\r\nHoisin sauce\r\nInstructions:\r\nPrepare Duck: Clean the duck and pat it dry. Mix honey, Shaoxing wine, soy sauce, five-spice powder, and salt. Rub this mixture inside and outside of the duck. Let the duck marinate for at least 4 hours, preferably overnight, in the refrigerator.\r\n\r\nAir-Dry the Duck: Hang the duck in a cool, windy place for 24 hours, or place it in the refrigerator uncovered, to dry out the skin.\r\n\r\nRoast the Duck: Preheat the oven to 180&deg;C (350&deg;F). Place the duck on a rack in a roasting pan and roast for about 1 hour and 20 minutes, or until the skin is richly browned and crispy. Turn the duck every 20 minutes to ensure even cooking.\r\n\r\nPrepare to Serve: Carve the duck and slice the meat and skin. Warm the pancakes.\r\n\r\nServe: Serve the duck with warm pancakes, cucumber, spring onions, and hoisin sauce. Each diner can assemble their own pancake with slices of duck, cucumber, spring onions, and a dollop of hoisin sauce.\r\n\r\n'),
(57, 'Ming&#039;s Special Mapo Tofu', '2024-03-03 20:12:58', 'Ingredients:\r\n1 block (about 400g) soft tofu, cut into cubes\r\n150g minced pork (or beef)\r\n2 tbsp Sichuan bean paste (doubanjiang)\r\n1 tbsp fermented black beans, rinsed and mashed\r\n2 cloves garlic, minced\r\n1 tsp ginger, minced\r\n1 tsp Sichuan peppercorns, ground\r\n2 tbsp vegetable oil\r\n1 tsp sugar\r\n1/2 cup (120ml) chicken stock or water\r\n1 tsp cornstarch mixed with 2 tbsp water (cornstarch slurry)\r\n2 green onions, chopped\r\n1 tsp chili oil (optional)\r\nInstructions:\r\nCook Tofu: Bring a pot of water to a gentle simmer. Add tofu and simmer for about 5 minutes. Drain and set aside.\r\n\r\nCook Pork: Heat oil in a wok over medium heat. Add minced pork and cook until browned. Set aside.\r\n\r\nSaut&eacute; Aromatics: In the same wok, add more oil if needed. Add garlic, ginger, and Sichuan peppercorns, and saut&eacute; until fragrant.\r\n\r\nAdd Bean Paste: Stir in Sichuan bean paste and black beans. Cook for a minute, then add back the cooked pork.\r\n\r\nAdd Tofu: Gently fold in the tofu and sugar, trying not to break the tofu cubes.\r\n\r\nAdd Stock: Pour in chicken stock, bring to a simmer, and cook for about 5 minutes.\r\n\r\nThicken Sauce: Add the cornstarch slurry and stir gently until the sauce thickens.\r\n\r\nFinish and Serve: Sprinkle with chopped green onions and drizzle with chili oil. Serve hot with steamed rice.'),
(58, 'Ming&#039;s Golden Fried Rice', '2024-03-03 20:13:36', 'Ingredients:\r\n4 cups cooked and cooled jasmine rice\r\n200g shrimp, peeled and deveined\r\n100g frozen peas, thawed\r\n2 eggs, beaten\r\n3 tbsp vegetable oil\r\n2 cloves garlic, minced\r\n1 tsp ginger, minced\r\n2 tbsp soy sauce\r\n1 tsp sesame oil\r\nSalt and white pepper to taste\r\n2 green onions, chopped\r\nInstructions:\r\nPrepare Ingredients: Ensure the rice is cold and grains are separated. Beat the eggs lightly.\r\n\r\nCook Shrimp: Heat 1 tbsp oil in a wok over high heat. Add shrimp and stir-fry until cooked. Remove and set aside.\r\n\r\nScramble Eggs: In the same wok, add a little more oil. Pour in beaten eggs and scramble. Once cooked, remove and set aside with shrimp.\r\n\r\nSaut&eacute; Aromatics: Heat the remaining oil in the wok. Add garlic and ginger, and saut&eacute; until fragrant.\r\n\r\nFry Rice: Add the rice to the wok. Stir-fry');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
