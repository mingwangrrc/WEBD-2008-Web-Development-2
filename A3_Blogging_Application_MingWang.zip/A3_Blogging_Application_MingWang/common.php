<!----------------

    Assignment 3 - Blog Application
    Name: Ming Wang
    Date: April 03. 2024
    Description: Blog Application

------------------>

<header>
    <a href="index.php"><img src="bubble100.jpg"><h1>My Amazing Blog</h1></a>
</header>

<!--
<nav>
    <ul>
        <li><a href="insert.php">Insert</a></li>
        <li><a href="select.php">Select</a></li>
        <li><a href="select_where.php">Select Where</a></li>
        <li><a href="update.php">Update</a></li>
    </ul>
</nav>
-->
