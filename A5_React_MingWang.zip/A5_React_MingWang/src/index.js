/******w**************
    
    Assignment 5 Javascript Frameworks Using React
    Name: Ming Wang 
    Date: April 24. 2024
    
*********************/

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import App from "./App";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <App />
  </StrictMode>
);
